<?php
require_once "conexion.db.php";

function limpiar($v) {
  return trim($v ?? '');
}

$nombre  = limpiar($_POST['name'] ?? '');
$tel     = limpiar($_POST['phone'] ?? '');
$email   = limpiar($_POST['email'] ?? '');
$pais_id = (int)($_POST['pais_id'] ?? 0);
$mensaje = limpiar($_POST['message'] ?? '');

if ($nombre === '' || $tel === '' || $email === '' || $pais_id <= 0 || $mensaje === '') {
  die("Faltan campos obligatorios");
}

// archivo
$archivoGuardado = null;
if (!empty($_FILES['userfile']['name'])) {
  $dir = __DIR__ . '/uploads';
  if (!is_dir($dir)) mkdir($dir, 0775, true);

  $nombreArchivo = time() . '_' . basename($_FILES['userfile']['name']);
  $destino = $dir . '/' . $nombreArchivo;

  if (move_uploaded_file($_FILES['userfile']['tmp_name'], $destino)) {
    $archivoGuardado = 'uploads/' . $nombreArchivo;
  }
}

// insertar
$stmt = $mysqli->prepare("INSERT INTO contacto (nombre, telefono, email, pais_id, mensaje, archivo) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssiss", $nombre, $tel, $email, $pais_id, $mensaje, $archivoGuardado);
$stmt->execute();

if ($stmt->affected_rows > 0) {
  header("Location: success.html");
  exit;
} else {
  die("Error al guardar el contacto");
}
